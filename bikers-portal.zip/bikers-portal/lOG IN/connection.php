<?php

$databaseHost = 'localhost';
$databaseName = 'bikers-portal';
$databaseUsername = 'root';
$databasePassword = '';
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);