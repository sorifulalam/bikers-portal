<!doctype html>
<html lang="en">


<?php
    include_once("connection.php");
    session_start();
    if(isset($_POST['signUp'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
    
        if (empty($name) || empty($email) || empty($password)) {
    
            if (empty($name)) {
                echo "<font color='red'>Name field is empty.</font><br/>";
            }
    
        
    
            if (empty($email)) {
                echo "<font color='red'>Email field is empty.</font><br/>";
            }
    
        
            if (empty($password)) {
                echo "<font color='red'>Password field is empty.</font><br/>";
            }
        } else {
            $query = "INSERT INTO users(name,email,password) VALUES('$name','$email','$password')";
            $result = mysqli_query($mysqli, $query);
            if ($result == true) {
                $_SESSION['email'] = $email;
                $_SESSION['password'] = $password;
                header("Location: ../home/index.html");
            } else {
                echo "you have a error";
            }
        }
    }

    ?>


<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
        name="viewport">
    <meta content="ie=edge" http-equiv="X-UA-Compatible">
    <title>Sing Up</title>
    <link href="./assets/img/logo.svg" rel="icon">
    <link href="./assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />
</head>

<body>


    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark ">
        <div class="container">

            <a class="navbar-brand" href="">
                <img class="navbarBrand" src="assets/img/logo.svg" alt="">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <!--  <div class="col-8">-->
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../home/index.html">HOME</a>
                    </li>
                    <li>
                        <a class="nav-link" href="../parts%20page/index.html">OUR PRODUCTS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">CONTACT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../lOG%20IN/index.html">LOGIN</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../sing%20up/index.html">SIGN UP</a>
                    </li>


                </ul>


            </div>
        </div>
    </nav>
    <div class="singup ">

        <div class="singup-box">
            <div class="row w-100">
                <div class="col-12">
                    <form method="post">
                        <h1 class="text-center text-dark mt-4 mb-4">SING UP</h1>
                        <i class="fas fa-user"></i>
                        <input class="form" type="text" placeholder="Enter Name" name="name" required><br>
                        <i class="fas fa-user"></i>
                        <input class="form" type="text" placeholder="Enter Email" name="email" required><br>
                        <i class="fas fa-user"></i>
                        <input class="form" type="text" placeholder="Enter Password" name="password" required><br>
                        <button name="signUp" type="submit" class="signupbtn">Sign Up</button>
                        <h5 class="text-center">Already have an account?<br> <a href="../lOG%20IN/index.html">Log
                                In.</a></h5>
                    </form>
                </div>
            </div>


        </div>

    </div>


    <footer class="bg-dark footer">
        <div class="container">
            <div class="row w-100">
                <div class="col-lg-3  col-sm-12 col-md-6 text-white pt-4">
                    <p> <a href="#" class="text-decoration-none text-white margin">+44 345 678 903</a></p>
                    <p> <a href="#" class="text-decoration-none text-white margin">Bikersportal@mail.com</a></p>
                    <p> <a href="#" class="text-decoration-none text-white">Contact us</a></p>
                </div>

                <div class="col-lg-3  col-sm-12 col-md-6 text-white pt-4">
                    <p> <a href="#" class="text-decoration-none text-white ">Contact Us</a></p>
                    <p> <a href="#" class="text-decoration-none text-white ">Ordering & Payment</a></p>
                    <p> <a href="#" class="text-decoration-none text-white ">Shipping</a></p>
                    <p> <a href="#" class="text-decoration-none text-white">Returns</a></p>
                    <p> <a href="#" class="text-decoration-none text-white">FAQ</a></p>
                    <p> <a href="#" class="text-decoration-none text-white">Sizing Guide</a></p>
                </div>
                <div class="col-lg-3  col-sm-12 col-md-6 text-white pt-4">
                    <p> <a href="#" class="text-decoration-none text-white margin">Privacy Policy</a></p>
                    <p> <a href="#" class="text-decoration-none text-white margin">Terms & Conditions</a></p>
                    <p> <a href="#" class="text-decoration-none text-white">Press Enquiries</a></p>
                </div>
                <div class="col-lg-3 col-sm-12 col-md-6 text-white pt-4">
                    <p> <a href="#" class="text-decoration-none text-white margin"><i class=" fab fa-facebook"></i>
                            Facebook</a></p>
                    <p> <a href="#" class="text-decoration-none text-white margin"><i class=" fab fa-twitter"></i>
                            Twitter</a></p>
                    <p> <a href="#" class="text-decoration-none text-white"><i class=" fab fa-instagram-square"></i>
                            Instagram</a></p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"
        integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js"
        integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc"
        crossorigin="anonymous"></script>
</body>

</html>